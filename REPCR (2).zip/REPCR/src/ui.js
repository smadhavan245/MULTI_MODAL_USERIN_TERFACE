const GRID_ROWS = 3;
const GRID_COLS = 3;

export function createUI({ gridEl, buttons, onAction }){
    const tiles = [];
    let focusedIndex = 0;
    const history = [];

    function buildGrid(){
        gridEl.innerHTML = '';
        for (let i=0;i<GRID_ROWS*GRID_COLS;i++){
            const el = document.createElement('button');
            el.className = 'tile';
            el.setAttribute('role','gridcell');
            el.textContent = `Tile ${i+1}`;
            el.addEventListener('click', () => select());
            gridEl.appendChild(el);
            tiles.push(el);
        }
        focus(0);
    }

    function focus(index){
        if (index < 0 || index >= tiles.length) return;
        tiles.forEach(t => t.classList.remove('focused'));
        tiles[index].classList.add('focused');
        focusedIndex = index;
        tiles[index].scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
    }

    function move(direction){
        const row = Math.floor(focusedIndex / GRID_COLS);
        const col = focusedIndex % GRID_COLS;
        let r=row,c=col;
        if (direction==='up') r = Math.max(0, row-1);
        if (direction==='down') r = Math.min(GRID_ROWS-1, row+1);
        if (direction==='left') c = Math.max(0, col-1);
        if (direction==='right') c = Math.min(GRID_COLS-1, col+1);
        const next = r*GRID_COLS + c;
        if (next !== focusedIndex) focus(next);
    }

    function home(){
        history.push(focusedIndex);
        focus(0);
    }

    function back(){
        const prev = history.pop();
        if (typeof prev === 'number') focus(prev);
    }

    function select(){
        tiles.forEach(t => t.classList.remove('selected'));
        tiles[focusedIndex].classList.add('selected');
        // Example action on select
        // In a real app, route or perform operation here
    }

    function handleAction(action){
        if (!action) return;
        if (['up','down','left','right'].includes(action)) move(action);
        else if (action==='home') home();
        else if (action==='back') back();
        else if (action==='select') select();
    }

    buttons.home.addEventListener('click', () => onAction('home'));
    buttons.back.addEventListener('click', () => onAction('back'));
    buttons.select.addEventListener('click', () => onAction('select'));
    buttons.stop.addEventListener('click', () => {
        if (window.stopMultimodal) {
            window.stopMultimodal();
        }
    });

    // If a grid element is provided, build tiles (launcher view uses custom renderer)
    if (gridEl) buildGrid();

    return { handleAction };
}


