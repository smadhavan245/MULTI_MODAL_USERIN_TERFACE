// Gaze controller using MediaPipe FaceMesh. Approximate gaze to directional actions.

export function createGazeController({ video, canvas, onAction, onStatus }){
    let running = false;
    let camera = null;
    let faceMesh = null;
    const ctx = canvas.getContext('2d');

    // Smoothing and debounce - optimized for speed
    const history = [];
    const HISTORY_SIZE = 3; // Reduced for faster response
    let lastEmitAt = 0;
    const EMIT_COOLDOWN_MS = 100; // Much faster detection

    function isSupported(){
        return !!window.FaceMesh && !!window.Camera;
    }

    async function start(){
        if (!isSupported()){
            onStatus?.('Gaze not supported (FaceMesh/Camera missing)', 'warn');
            return;
        }
        running = true;
        // Setup FaceMesh
        faceMesh = new window.FaceMesh({ locateFile: (f) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${f}` });
        faceMesh.setOptions({
            maxNumFaces: 1,
            refineLandmarks: true,
            minDetectionConfidence: 0.5,
            minTrackingConfidence: 0.5
        });
        faceMesh.onResults(onResults);

        // Camera input
        camera = new window.Camera(video, {
            onFrame: async () => {
                await faceMesh.send({ image: video });
            },
            width: 640,
            height: 360
        });
        await camera.start();
        onStatus?.('Gaze started', 'ok');
    }

    async function stop(){
        running = false;
        if (camera) { try { await camera.stop(); } catch(_){} camera = null; }
        if (faceMesh && faceMesh.close) { try { await faceMesh.close(); } catch(_){} }
        ctx.clearRect(0,0,canvas.width,canvas.height);
        onStatus?.('Gaze stopped', 'warn');
    }

    function onResults(results){
        if (!running) return;
        const width = canvas.width = results.image.width;
        const height = canvas.height = results.image.height;
        ctx.save();
        ctx.clearRect(0,0,width,height);
        ctx.drawImage(results.image, 0, 0, width, height);

        const faces = results.multiFaceLandmarks || [];
        if (faces.length === 0) { ctx.restore(); return; }
        const lm = faces[0];
        // Iris landmarks: approximate pupil center using landmarks 468-473 when refineLandmarks=true
        const irisLeft = averagePoints([468,469,470,471].map(i => lm[i]));
        const irisRight = averagePoints([473,474,475,476].map(i => lm[i]));
        const gazeX = (irisLeft.x + irisRight.x)/2;
        const gazeY = (irisLeft.y + irisRight.y)/2;

        // Draw
        drawPoint(irisLeft, 'cyan');
        drawPoint(irisRight, 'cyan');

        // Accumulate normalized position
        history.push({ x: gazeX, y: gazeY });
        if (history.length > HISTORY_SIZE) history.shift();
        const avg = averagePoints(history);

        const now = performance.now();
        if (now - lastEmitAt < EMIT_COOLDOWN_MS) { ctx.restore(); return; }

        // Direction thresholds - more sensitive for faster detection
        const LEFT_THRESH = 0.35;
        const RIGHT_THRESH = 0.65;
        const UP_THRESH = 0.35;
        const DOWN_THRESH = 0.65;

        let action = null;
        if (avg.x < LEFT_THRESH) action = 'left';
        else if (avg.x > RIGHT_THRESH) action = 'right';
        else if (avg.y < UP_THRESH) action = 'up';
        else if (avg.y > DOWN_THRESH) action = 'down';

        if (action){
            lastEmitAt = now;
            onAction?.(action);
        }

        ctx.restore();
    }

    function drawPoint(p, color='lime'){
        const x = p.x * canvas.width;
        const y = p.y * canvas.height;
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, Math.PI*2);
        ctx.fillStyle = color;
        ctx.fill();
    }

    function averagePoints(arr){
        if (!arr || arr.length===0) return { x:0.5, y:0.5 };
        const s = arr.reduce((a,b)=>({ x:a.x+b.x, y:a.y+b.y }), { x:0, y:0 });
        return { x: s.x/arr.length, y: s.y/arr.length };
    }

    return { start, stop, isSupported };
}


