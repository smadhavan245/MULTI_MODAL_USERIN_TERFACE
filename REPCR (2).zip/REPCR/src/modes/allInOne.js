// All-in-One controller: runs gaze, gesture, and voice together and arbitrates

export function createAllInOneController({ gaze, gesture, voice, onAction, onStatus }){
    let running = false;
    let unsubscribeFns = [];

    function isSupported(){
        return (gaze?.isSupported?.() || gesture?.isSupported?.() || voice?.isSupported?.());
    }

    async function start(){
        if (running) return;
        running = true;
        onStatus?.('All-in-One starting...', 'ok');
        // Start supported controllers
        await Promise.all([
            gaze?.isSupported?.() ? gaze.start() : Promise.resolve(),
            gesture?.isSupported?.() ? gesture.start() : Promise.resolve(),
            voice?.isSupported?.() ? voice.start() : Promise.resolve()
        ]);
        // Listen globally by proxying to onAction with arbitration
        attachArbitration();
        onStatus?.('All-in-One active', 'ok');
    }

    async function stop(){
        running = false;
        detachArbitration();
        await Promise.all([
            gaze?.stop?.(),
            gesture?.stop?.(),
            voice?.stop?.()
        ]);
        onStatus?.('All-in-One stopped', 'warn');
    }

    // Simple arbitration: prefer direct/explicit sources by recency
    // We assume controllers call the shared dispatcher; we also listen to DOM custom events for page actions
    function attachArbitration(){
        // Hook the global dispatcher via DOM custom event from main dispatcher
        const handler = (e) => arbitrate(e.detail);
        window.addEventListener('app-action', handler);
        unsubscribeFns.push(() => window.removeEventListener('app-action', handler));
    }

    function detachArbitration(){
        unsubscribeFns.forEach(fn => { try { fn(); } catch(_){} });
        unsubscribeFns = [];
    }

    let lastAt = 0;
    const COOLDOWN = 50; // Ultra-high frequency for responsive control
    function arbitrate(action){
        const now = performance.now();
        if (now - lastAt < COOLDOWN) return;
        lastAt = now;
        onAction?.(action);
    }

    return { start, stop, isSupported };
}

 