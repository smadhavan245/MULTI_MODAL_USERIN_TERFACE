// Voice controller using Web Speech API (SpeechRecognition)

export function createVoiceController({ onAction, onStatus }){
    let recognition = null;
    let running = false;

    function isSupported(){
        return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
    }

    async function start(){
        if (!isSupported()){
            onStatus?.('Voice not supported in this browser', 'warn');
            return;
        }
        const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SR();
        recognition.lang = 'en-US';
        recognition.continuous = true;
        recognition.interimResults = false;

        recognition.onresult = (ev) => {
            const last = ev.results[ev.results.length - 1];
            const text = (last[0].transcript || '').trim().toLowerCase();
            const mapped = mapTextToAction(text);
            if (mapped){
                onStatus?.(`Heard: ${text}`, 'ok');
                onAction?.(mapped);
            } else {
                onStatus?.(`Unmapped: ${text}`, 'warn');
            }
        };
        recognition.onerror = (e) => onStatus?.(`Voice error: ${e.error}`, 'err');
        recognition.onend = () => { if (running) recognition.start(); };

        running = true;
        recognition.start();
        onStatus?.('Voice started. Try saying "up", "down", "left", "right", "home", "back", "select"', 'ok');
    }

    async function stop(){
        running = false;
        try { recognition && recognition.stop(); } catch(_){}
        onStatus?.('Voice stopped', 'warn');
    }

    function mapTextToAction(t){
        if (/^(up|top|north)$/i.test(t)) return 'up';
        if (/^(down|bottom|south)$/i.test(t)) return 'down';
        if (/^(left|west)$/i.test(t)) return 'left';
        if (/^(right|east)$/i.test(t)) return 'right';
        if (/^(home|start|begin)$/i.test(t)) return 'home';
        if (/^(back|previous)$/i.test(t)) return 'back';
        if (/^(select|enter|open|ok)$/i.test(t)) return 'select';
        if (/^(stop|end|quit|exit)$/i.test(t)) {
            if (window.stopMultimodal) {
                window.stopMultimodal();
            }
            return 'stop';
        }
        return null;
    }

    return { start, stop, isSupported };
}


