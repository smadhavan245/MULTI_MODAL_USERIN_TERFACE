// Gesture controller using MediaPipe Hands. Map palm orientation and finger state to arrows and actions.

export function createGestureController({ video, canvas, onAction, onStatus }){
    let running = false;
    let camera = null;
    let hands = null;
    const ctx = canvas.getContext('2d');
    let lastEmitAt = 0;
    const EMIT_COOLDOWN_MS = 80; // Much faster gesture detection

    function isSupported(){
        return !!window.Hands && !!window.Camera;
    }

    async function start(){
        if (!isSupported()){
            onStatus?.('Gesture not supported (Hands/Camera missing)', 'warn');
            return;
        }
        running = true;
        hands = new window.Hands({ locateFile: (f) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${f}` });
        hands.setOptions({
            maxNumHands: 1,
            modelComplexity: 1,
            minDetectionConfidence: 0.5,
            minTrackingConfidence: 0.5
        });
        hands.onResults(onResults);

        camera = new window.Camera(video, {
            onFrame: async () => { await hands.send({ image: video }); },
            width: 640,
            height: 360
        });
        await camera.start();
        onStatus?.('Gesture started', 'ok');
    }

    async function stop(){
        running = false;
        if (camera) { try { await camera.stop(); } catch(_){} camera = null; }
        if (hands && hands.close) { try { await hands.close(); } catch(_){} }
        ctx.clearRect(0,0,canvas.width,canvas.height);
        onStatus?.('Gesture stopped', 'warn');
    }

    function onResults(results){
        if (!running) return;
        const width = canvas.width = results.image.width;
        const height = canvas.height = results.image.height;
        ctx.save();
        ctx.clearRect(0,0,width,height);
        ctx.drawImage(results.image, 0, 0, width, height);

        const handsLm = results.multiHandLandmarks || [];
        if (handsLm.length === 0) { ctx.restore(); return; }
        const lm = handsLm[0];

        // Use wrist to index knuckle vector to infer left/right, and wrist to middle MCP for up/down
        const wrist = lm[0];
        const indexMcp = lm[5];
        const middleMcp = lm[9];

        const vx = indexMcp.x - wrist.x;
        const vy = middleMcp.y - wrist.y;

        let action = null;
        const now = performance.now();
        if (now - lastEmitAt >= EMIT_COOLDOWN_MS){
            // More sensitive thresholds for faster detection
            if (vx < -0.04) action = 'left';
            else if (vx > 0.04) action = 'right';
            else if (vy < -0.04) action = 'up';
            else if (vy > 0.04) action = 'down';

            // Fist (select) or palm open (home/back)
            const isFist = isFingerCurled(lm, 8) && isFingerCurled(lm, 12) && isFingerCurled(lm, 16) && isFingerCurled(lm, 20);
            const isOpenPalm = !isFingerCurled(lm, 8) && !isFingerCurled(lm, 12) && !isFingerCurled(lm, 16) && !isFingerCurled(lm, 20);
            if (!action){
                if (isFist) action = 'select';
                else if (isOpenPalm){
                    // Decide home vs back by thumb direction
                    const thumbTip = lm[4];
                    if (thumbTip.x < wrist.x) action = 'home'; else action = 'back';
                }
            }
            if (action){
                lastEmitAt = now;
                onAction?.(action);
            }
        }

        drawHand(lm);
        ctx.restore();
    }

    function isFingerCurled(lm, tipIndex){
        // tip vs pip distance threshold
        const pipIndex = tipIndex - 2;
        const mcpIndex = tipIndex - 3;
        const tip = lm[tipIndex];
        const pip = lm[pipIndex];
        const mcp = lm[mcpIndex];
        const dp = distance(tip, mcp);
        const dp2 = distance(pip, mcp);
        return dp < dp2 * 0.8;
    }

    function distance(a,b){
        const dx = a.x-b.x, dy=a.y-b.y;
        return Math.hypot(dx,dy);
    }

    function drawHand(lm){
        for (const p of lm){
            ctx.beginPath();
            ctx.arc(p.x*canvas.width, p.y*canvas.height, 3, 0, Math.PI*2);
            ctx.fillStyle = 'orange';
            ctx.fill();
        }
    }

    return { start, stop, isSupported };
}


