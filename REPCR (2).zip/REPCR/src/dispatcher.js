export function createDispatcher({ onAction, onStatus }){
    const audioCtx = typeof window !== 'undefined' && (window.AudioContext || window.webkitAudioContext) ? new (window.AudioContext || window.webkitAudioContext)() : null;

    const listeners = new Set();

    function emit(action){
        if (!action) return;
        onAction?.(action);
        listeners.forEach(l => l(action));
        // also broadcast to pages for routing behaviors
        try {
            const ev = new CustomEvent('app-action', { detail: action });
            window.dispatchEvent(ev);
        } catch(_){ }
        beep('action');
    }

    function status(text, level='ok'){
        onStatus?.(text, level);
    }

    function subscribe(listener){
        listeners.add(listener);
        return () => listeners.delete(listener);
    }

    function beep(type='action'){
        if (!audioCtx) return;
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.type = 'sine';
        const now = audioCtx.currentTime;
        const duration = type==='mode' ? 0.08 : 0.05;
        const freq = type==='mode' ? 660 : 520;
        o.frequency.setValueAtTime(freq, now);
        g.gain.setValueAtTime(0.0001, now);
        g.gain.exponentialRampToValueAtTime(0.15, now + 0.005);
        g.gain.exponentialRampToValueAtTime(0.0001, now + duration);
        o.connect(g).connect(audioCtx.destination);
        o.start(now);
        o.stop(now + duration + 0.01);
    }

    return { emit, status, subscribe, beep };
}


