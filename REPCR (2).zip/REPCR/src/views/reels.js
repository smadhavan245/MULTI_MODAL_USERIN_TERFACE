export function renderReels(root, { onAction }){
    root.innerHTML = '';
    const list = document.createElement('div');
    list.style.display = 'grid';
    list.style.gap = '12px';
    list.style.maxHeight = '60vh';
    list.style.overflow = 'auto';
    for (let i=1;i<=20;i++){
        const reel = document.createElement('div');
        reel.style.height = '220px';
        reel.style.borderRadius = '12px';
        reel.style.background = 'rgba(255,255,255,0.06)';
        reel.style.border = '1px solid rgba(255,255,255,0.08)';
        reel.style.display = 'flex';
        reel.style.alignItems = 'center';
        reel.style.justifyContent = 'center';
        reel.style.color = '#e6e8ff';
        reel.style.fontWeight = '700';
        reel.textContent = `Reel ${i}`;
        list.appendChild(reel);
    }
    root.appendChild(list);

    function handle(action){
        if (action==='up') list.scrollBy({ top: -260, behavior: 'smooth' });
        else if (action==='down') list.scrollBy({ top: 260, behavior: 'smooth' });
        else if (action==='home') location.hash = '#/launcher';
        else if (action==='back') history.back();
    }

    window.__reelsHandler && window.removeEventListener('app-action', window.__reelsHandler);
    window.__reelsHandler = (e) => handle(e.detail);
    window.addEventListener('app-action', window.__reelsHandler);
}


