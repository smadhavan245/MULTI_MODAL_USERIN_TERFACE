const APPS = [
    { id: 'reels', name: 'Reels', route: '#/reels' },
    { id: 'news', name: 'News', route: '#/settings' },
    { id: 'music', name: 'Music', route: '#/settings' },
    { id: 'gallery', name: 'Gallery', route: '#/settings' },
    { id: 'settings', name: 'Settings', route: '#/settings' },
    { id: 'about', name: 'About', route: '#/settings' }
];

export function renderLauncher(root, { onAction }){
    root.innerHTML = '';
    const grid = document.createElement('div');
    grid.className = 'app-grid';
    root.appendChild(grid);

    const tiles = APPS.map((app, i) => {
        const el = document.createElement('button');
        el.className = 'app-tile';
        el.innerHTML = `<div class="app-icon"></div><div>${app.name}</div>`;
        el.addEventListener('click', () => { location.hash = app.route; });
        grid.appendChild(el);
        return el;
    });

    let focused = 0;
    tiles[focused].classList.add('focused');
    function updateFocus(idx){
        tiles[focused].classList.remove('focused');
        focused = (idx+tiles.length)%tiles.length;
        tiles[focused].classList.add('focused');
        tiles[focused].scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
    }

    function handle(action){
        const cols = 3;
        const row = Math.floor(focused/cols);
        const col = focused%cols;
        if (action==='left') updateFocus(row*cols + Math.max(0,col-1));
        else if (action==='right') updateFocus(row*cols + Math.min(cols-1,col+1));
        else if (action==='up') updateFocus(Math.max(0, focused - cols));
        else if (action==='down') updateFocus(Math.min(tiles.length-1, focused + cols));
        else if (action==='select') tiles[focused].click();
        else if (action==='home') location.hash = '#/launcher';
    }

    // Attach global handler for actions
    window.__launcherHandler && window.removeEventListener('app-action', window.__launcherHandler);
    window.__launcherHandler = (e) => handle(e.detail);
    window.addEventListener('app-action', window.__launcherHandler);
}


