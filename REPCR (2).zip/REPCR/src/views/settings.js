export function renderSettings(root){
    root.innerHTML = '';
    const wrap = document.createElement('div');
    wrap.style.display = 'grid';
    wrap.style.gap = '12px';
    wrap.innerHTML = `
        <div style="opacity:.9">Settings (demo)</div>
        <label style="display:flex;align-items:center;gap:8px">
            <span>Action beep</span>
            <input id="cfg-beep" type="checkbox" checked disabled />
        </label>
        <div style="font-size:12px;color:#9aa3c7">More settings can go here.</div>
    `;
    root.appendChild(wrap);
}


