import { renderLauncher } from './views/launcher.js';
import { renderReels } from './views/reels.js';
import { renderSettings } from './views/settings.js';

export function createRouter({ root, onAction }){
    function navigate(hash){
        if (!hash) hash = '#/launcher';
        if (location.hash !== hash) location.hash = hash;
        render();
    }

    function render(){
        const route = location.hash || '#/launcher';
        if (route.startsWith('#/launcher')) renderLauncher(root, { onAction });
        else if (route.startsWith('#/reels')) renderReels(root, { onAction });
        else if (route.startsWith('#/settings')) renderSettings(root, { onAction });
        else renderLauncher(root, { onAction });
        // update tabbar active state
        document.querySelectorAll('.tabbar button').forEach(btn => {
            const active = btn.getAttribute('data-route') === route;
            btn.style.opacity = active ? '1' : '0.7';
        });
    }

    function init(){
        window.addEventListener('hashchange', render);
        document.getElementById('tab-launcher')?.addEventListener('click', () => navigate('#/launcher'));
        document.getElementById('tab-reels')?.addEventListener('click', () => navigate('#/reels'));
        document.getElementById('tab-settings')?.addEventListener('click', () => navigate('#/settings'));
        render();
    }

    return { init, navigate };
}


