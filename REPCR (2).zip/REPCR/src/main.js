import { createDispatcher } from './dispatcher.js';
import { createUI } from './ui.js';
import { createRouter } from './router.js';
import { createAllInOneController } from './modes/allInOne.js';
import { createGazeController } from './modes/gaze.js';
import { createGestureController } from './modes/gesture.js';
import { createVoiceController } from './modes/voice.js';

const state = {
	activeMode: null,
	controllers: {},
	dispatcher: null,
	ui: null
};

function setHUD(key, value, extraClass) {
	const el = document.getElementById(`hud-${key}`);
    if (!el) return;
    el.textContent = value;
    el.className = extraClass ? extraClass : '';
}

function init() {
    state.dispatcher = createDispatcher({
        onAction: (action) => {
            state.ui.handleAction(action);
            setHUD('action', action);
        },
        onStatus: (text, level = 'ok') => {
            setHUD('status', text, level);
        }
    });

    state.ui = createUI({
        gridEl: null,
        buttons: {
            home: document.getElementById('btn-home'),
            back: document.getElementById('btn-back'),
            select: document.getElementById('btn-select'),
            stop: document.getElementById('btn-stop')
        },
        onAction: (action) => state.dispatcher.emit(action)
    });

    const video = document.getElementById('input-video');
    const canvas = document.getElementById('output-canvas');

    state.controllers.gaze = createGazeController({ video, canvas, onAction: state.dispatcher.emit, onStatus: state.dispatcher.status });
    state.controllers.gesture = createGestureController({ video, canvas, onAction: state.dispatcher.emit, onStatus: state.dispatcher.status });
    state.controllers.voice = createVoiceController({ onAction: state.dispatcher.emit, onStatus: state.dispatcher.status });
    state.controllers.all = createAllInOneController({ gaze: state.controllers.gaze, gesture: state.controllers.gesture, voice: state.controllers.voice, onAction: state.dispatcher.emit, onStatus: state.dispatcher.status });

    // Router and pages
    const root = document.getElementById('app-root');
    const router = createRouter({ root, onAction: (a) => state.dispatcher.emit(a) });
    router.init();

    // Mode selector
    document.querySelectorAll('input[name="mode"]').forEach(r => {
        r.addEventListener('change', () => activateMode(r.value));
    });

    // Default to Voice if supported, else Gesture
    const defaultMode = state.controllers.voice.isSupported() ? 'voice' : 'gesture';
    document.querySelector(`input[name="mode"][value="${defaultMode}"]`).checked = true;
    activateMode(defaultMode);

    setHUD('action', '-');
    setHUD('status', 'Ready', 'ok');
}

async function activateMode(mode) {
    if (state.activeMode === mode) return;
    // Stop existing
    if (state.activeMode && state.controllers[state.activeMode]) {
        await state.controllers[state.activeMode].stop();
    }
    state.activeMode = mode;
    setHUD('mode', mode);
    // Start selected
    try {
        await state.controllers[mode].start();
        state.dispatcher.beep('mode');
    } catch (e) {
        console.error(e);
        state.dispatcher.status(`Failed to start ${mode}`, 'err');
    }
}

// Global stop function to end all processes
async function stopAll() {
    if (state.activeMode && state.controllers[state.activeMode]) {
        await state.controllers[state.activeMode].stop();
        state.activeMode = null;
        setHUD('mode', 'Stopped');
        setHUD('status', 'All processes stopped', 'warn');
        state.dispatcher.beep('mode');
    }
}

// Expose stop function globally
window.stopMultimodal = stopAll;

window.addEventListener('DOMContentLoaded', init);


