# Multimodal Control Web App (Gaze · Gesture · Voice)

A client-only demo that lets you control a simple UI using any of three modes:
- Gaze (MediaPipe FaceMesh/Iris)
- Hand Gestures (MediaPipe Hands)
- Voice (Web Speech API)

## Features
- Mode selector to switch between Gaze, Gesture, and Voice
- Shared action dispatcher and HUD showing mode, last action, and status
- 3x3 focusable grid navigable via up/down/left/right, with home/back/select
- Visual and audio feedback for actions and mode changes

## Requirements
- Chromium-based browser (Chrome/Edge). Voice uses the Web Speech API.
- Camera/microphone permissions for Gaze/Gesture/Voice modes.
- Serve over https or http://localhost (required for camera/mic).

## Quick Start
1. Install a simple static server if you don’t have one:
   - Node: `npx http-server -c-1` or `npx serve`
   - Python: `python -m http.server 8080`
2. From the project root, run one of the servers and open:
   - `http://localhost:8080` (or the port shown by your server)
3. Allow camera and microphone permissions when prompted.
4. Select a mode in the header and try: up, down, left, right, home, back, select

## Controls by Mode
- Gaze:
  - Look left/right/up/down to navigate. Uses smoothed iris center with thresholds.
- Gesture:
  - Move hand horizontally/vertically to navigate.
  - Fist = select. Open palm: thumb left = home, thumb right = back.
- Voice:
  - Say: "up", "down", "left", "right", "home", "back", "select".

## Files
- `index.html` — Page with mode selector, HUD, grid, and video/canvas area.
- `styles.css` — Minimal UI styling.
- `src/main.js` — App bootstrap, mode activation, HUD wiring.
- `src/dispatcher.js` — Action bus and audio beeps.
- `src/ui.js` — Grid focus/navigation and button actions.
- `src/modes/gaze.js` — MediaPipe FaceMesh-based gaze to direction mapping.
- `src/modes/gesture.js` — MediaPipe Hands-based gesture mapping.
- `src/modes/voice.js` — Web Speech API voice commands.

## Notes
- MediaPipe models load from jsDelivr CDN; internet is required.
- Thresholds and cooldowns are conservative; adjust in code if needed.
- This is a demo; add real navigation/logic where `select` highlights tiles.

## Troubleshooting
- Camera not starting: ensure https or http://localhost and allow permissions.
- Voice not working: some browsers disable Web Speech API; try Chrome/Edge desktop.
- Performance: close other tabs using camera/mic; reduce video resolution in configs.
